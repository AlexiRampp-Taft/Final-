function setup() {
 
  createCanvas(400, 400);
  background(100);
  noStroke();

  fill(200);
  triangle(18, 18, 18, 360, 81, 360);
  
  fill(350);
  triangle(45, 45, 55, 200, 90, 300);

  fill(360);
  rect(100, 70, 60, 60);
  
  fill (250);
  arc(90, 60, 40, 20, 20, 50)
  
  fill(100);
  arc(300, 450, 80, 80, 95, 90);
  
  fill(150)
  rect(40, 40, 10, 10);

  fill(250);
  ellipse(252, 144, 72, 72);

  fill(200);
  triangle(200, 18, 300, 360, 280, 360);
  
  fill(200);
  triangle(18, 25, 200, 300, 24, 60);
  
  fill(300);
  triangle(350, 20, 20, 400, 90, 360)
  
  fill(430);
  ellipse(300, 100, 82, 82)
  
  fill(200);
  ellipse(100, 230, 20, 30);
  
  fill(90);
  rect(100, 100, 40, 40)
}